<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'piula.edu.ws');

/** MySQL database username */
define('DB_USER', 'piula.edu.ws');

/** MySQL database password */
define('DB_PASSWORD', 'Apineru22');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'tb|S%X9ET7EM,21s,KbhICN7R%>LjKJ|h5sD,y[j8*nVYVT]knzDzf(|s9b`O1!/');
define('SECURE_AUTH_KEY',  'iDIF (fyw8CLRn&zJUyW_!KRz]KAsC2@[L6`&?)[.?5bq!Ag3<AK|#;#1L9<2J_r');
define('LOGGED_IN_KEY',    '%7kmLFmaRWtN @%ZqBECAA#b]*S}PD.*Gm(VG+x]j9HMrCo/9q*1<+Gefe:4^*=Y');
define('NONCE_KEY',        '(rH<;bR/-`uk:6uwkX/B$z[N1q0LD66%k<7QL1[)&=FAp*36*CIx$ik2> e,msba');
define('AUTH_SALT',        'HWVt||lo(#h_pS.>C(pM!,;_Tsl{sj:r)@0ZLXJU-Rm=1:.m]PJW~(t/LkZ<!(T/');
define('SECURE_AUTH_SALT', ',FA&/7?|=][}d[PDd?(<Vv2^RH~6f$64W49)@-,QrB31h^jj]XYCq%ONCs@cR=W0');
define('LOGGED_IN_SALT',   'm~FglogU%1muzuuoxQf2QJtTauhU/~K}Yv=$=AI}<vJnG~ytMF~Gp`0?t(j,^u6~');
define('NONCE_SALT',       'Ik/jJ?h-Tu3Gsi5dtF;CG%ezy-uxS`RDNj-!DmKA,S)1~k&[elyKS>/w`n,l6>rW');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'piula_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
